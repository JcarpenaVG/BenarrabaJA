# Changelog

All notable changes to this package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## [Unreleased]

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [14.0.10] - 2024-04-03

This version is compatible with Unity 2022.3.24f1.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [14.0.9] - 2023-12-21

This version is compatible with Unity 2022.3.18f1.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [14.0.8] - 2023-09-27

This version is compatible with Unity 2022.3.11f1.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [14.0.7] - 2023-05-23

This version is compatible with Unity 2022.2.22f1.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [14.0.6] - 2023-03-24

This version is compatible with Unity 2022.2.13f1.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [14.0.5] - 2022-12-12

This version is compatible with Unity 2022.2.4f1.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [14.0.4] - 2022-11-04

This version is compatible with Unity 2022.2.2f1.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [14.0.3] - 2021-05-09

This version is compatible with Unity 2022.2.0b15.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [14.0.2] - 2021-02-04

This version is compatible with Unity 2022.2.0a14.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [14.0.1] - 2021-12-07

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [14.0.0] - 2021-11-17

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [13.1.2] - 2021-11-05

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [13.1.1] - 2021-10-04

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [13.1.0] - 2021-09-24

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [13.0.0] - 2021-09-01

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [12.0.0] - 2021-01-11

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [11.0.0] - 2020-10-21

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [10.2.0] - 2020-10-19

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [10.1.0] - 2020-10-12

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [10.0.0] - 2019-06-10

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [7.1.1] - 2019-09-05

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [7.0.1] - 2019-07-25

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

Started Changelog
